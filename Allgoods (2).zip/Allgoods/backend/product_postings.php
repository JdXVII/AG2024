<script type="module">
  import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-app.js";
  import { getDatabase, ref, onValue, update, remove, set } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-database.js";
  import { getStorage, ref as storageRef, deleteObject } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-storage.js";

  const firebaseConfig = {
    apiKey: "AIzaSyCSx9Dx9f6fbwBvf8b02Wo8W6py5mFkpzI",
    authDomain: "allgoods2024-5163a.firebaseapp.com",
    databaseURL: "https://allgoods2024-5163a-default-rtdb.firebaseio.com",
    projectId: "allgoods2024-5163a",
    storageBucket: "allgoods2024-5163a.appspot.com",
    messagingSenderId: "980525971714",
    appId: "1:980525971714:web:78849efcc5ac2325a7ea1b"
  };

  const app = initializeApp(firebaseConfig);
  const database = getDatabase(app);
  const storage = getStorage(app);

  const productTableBody = document.getElementById('product-table-body');

  function fetchProducts() {
    const productsRef = ref(database, 'upload_products');
    onValue(productsRef, (snapshot) => {
      productTableBody.innerHTML = '';
      snapshot.forEach((childSnapshot) => {
        const product = childSnapshot.val();
        if (product.status !== 'approved') {
          const productRow = document.createElement('tr');
          productRow.id = `product-${product.productId}`;
  
          // Fetch the storeName based on userId
          const vendorRef = ref(database, `vendors/${product.userId}`);
          onValue(vendorRef, (vendorSnapshot) => {
            const vendor = vendorSnapshot.val();
            const storeName = vendor.firstName + ' ' + vendor.lastName;
  
            // Create the product row
            productRow.innerHTML = `
              <td>
                <img class="pic" src="${product.imageUrls[0]}" width="90" alt="Product Image" onclick="openModal('${product.productId}')">
              </td>
              <td>${product.name}</td>
              <td>${storeName}</td>
              <td>${product.price}</td>
              <td class="action-btns">
                <button class="btn3 btn-view" onclick="viewProduct('${product.productId}')">View</button>
                <button class="btn1 btn-approve" onclick="approveProduct('${product.productId}')">Approve</button>
                <button class="btn2 btn-delete" onclick="deleteProduct('${product.productId}', '${product.userId}', '${product.imageUrls[0]}')">Decline</button>
              </td>
            `;
            productTableBody.appendChild(productRow);
          });
        }
      });
    });
  }

  // Function to view product details
  window.viewProduct = function(productId) {
    const productRef = ref(database, `upload_products/${productId}`);
    onValue(productRef, (snapshot) => {
      const product = snapshot.val();
      if (product) {
        // Set the product name and description in the modal
        document.getElementById('modal-product-name').innerText = product.name;
        document.getElementById('modal-product-description').innerText = product.description || 'No description available.';
        
        // Show the modal
        document.getElementById('description-modal').style.display = "block";
      }
    });
  };
  
  // Function to close the description modal
  window.closeDescriptionModal = function() {
    document.getElementById('description-modal').style.display = "none";
  };


  // Function to open the modal and display all images
  window.openModal = function(productId) {
    const modal = document.getElementById('image-modal');
    const modalImages = document.getElementById('modal-images');
    
    // Clear previous images
    modalImages.innerHTML = '';
    
    // Fetch product details
    const productRef = ref(database, `upload_products/${productId}`);
    onValue(productRef, (snapshot) => {
      const product = snapshot.val();
      product.imageUrls.forEach((imageUrl) => {
        const img = document.createElement('img');
        img.src = imageUrl;
        modalImages.appendChild(img);
      });
    });
    
      // Show the modal
      modal.style.display = "block";
    };
    
    // Close the modal when the user clicks on <span> (x)
    document.querySelector('.modal .close').onclick = function() {
      document.getElementById('image-modal').style.display = "none";
    };
    
    // Close the modal when the user clicks anywhere outside of the modal
    window.onclick = function(event) {
      if (event.target === document.getElementById('image-modal')) {
        document.getElementById('image-modal').style.display = "none";
      }
  };


  window.approveProduct = function(productId) {
    if (confirm("Are you sure you want to approve this product?")) {
      const productRef = ref(database, `upload_products/${productId}`);
      update(productRef, { status: 'approved' }).then(() => {
        const productRow = document.getElementById(`product-${productId}`);
        if (productRow) {
          productRow.remove();
        }
        alert('Product approved successfully');
      }).catch((error) => {
        console.error('Error approving product:', error);
      });
    }
  };

  window.deleteProduct = function(productId, userId, imageUrl) {
    if (confirm("Are you sure you want to decline this product?")) {
      const reason = prompt("Please enter the reason for declining this product:");
      if (reason) {
        const productRef = ref(database, `upload_products/${productId}`);
        const imageRef = storageRef(storage, imageUrl);
        const declinedProductRef = ref(database, `declined_products/${productId}`);
  
        // Fetch the product name
        onValue(productRef, (snapshot) => {
          const product = snapshot.val();
          const productName = product.name;
  
          // Store the decline reason, userId, productName, and isRead flag
          set(declinedProductRef, { 
            reason, 
            userId, 
            name: productName,
            isRead: false
          }).then(() => {
            // Remove the product and delete the image
            remove(productRef).then(() => {
              deleteObject(imageRef).then(() => {
                const productRow = document.getElementById(`product-${productId}`);
                if (productRow) {
                  productRow.remove();
                }
                alert('Product declined successfully');
              }).catch((error) => {
                console.error('Error deleting image:', error);
              });
            }).catch((error) => {
              console.error('Error deleting product:', error);
            });
          }).catch((error) => {
            console.error('Error storing decline reason:', error);
          });
        });
      }
    }
  };


  fetchProducts();
</script>
