<script type="module">
    import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
    import { getDatabase, ref, onValue, update, remove } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-database.js";
    import { getAuth, signInWithEmailAndPassword, deleteUser } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
    import { getStorage, ref as storageRef, deleteObject } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-storage.js";

    const firebaseConfig = {
      apiKey: "AIzaSyCSx9Dx9f6fbwBvf8b02Wo8W6py5mFkpzI",
      authDomain: "allgoods2024-5163a.firebaseapp.com",
      databaseURL: "https://allgoods2024-5163a-default-rtdb.firebaseio.com",
      projectId: "allgoods2024-5163a",
      storageBucket: "allgoods2024-5163a.appspot.com",
      messagingSenderId: "980525971714",
      appId: "1:980525971714:web:78849efcc5ac2325a7ea1b"
    };
    
    const app = initializeApp(firebaseConfig);
    const database = getDatabase(app);
    const auth = getAuth(app);
    const storage = getStorage(app);

    emailjs.init('U7K8sg-mpV38W9Vtm'); // EmailJS user ID

    const buyersRef = ref(database, 'buyers');

    // Function to approve buyer
    window.approveBuyer = function(buyerId, login_email) {
        if (!confirm("Are you sure you want to approve this vendor?")) {
            return;
        }
        const buyerRef = ref(database, 'buyers/' + buyerId);
        const currentTime = new Date().toISOString(); // Get current timestamp
        update(buyerRef, { status: 'approved', approvedAt: currentTime }) // Add approvedAt timestamp
            .then(() => {
                alert('Buyer approved');
                sendApprovalEmail(login_email);
            })
            .catch((error) => {
                console.error('Error approving buyer: ', error);
            });
    }


    // Function to decline buyer
    window.declineBuyer = function(buyerId, login_email, profileImageUrl, valididImageUrl) {
        if (!confirm("Are you sure you want to decline this vendor?")) {
            return; 
        }

        const reason = prompt("Please enter the reason for declining the buyer:");
        if (!reason) {
            alert("Decline reason is required");
            return;
        }
    
        sendEmail(reason, login_email);
    
        const buyerRef = ref(database, 'buyers/' + buyerId);
    
        onValue(buyerRef, (snapshot) => {
            const buyer = snapshot.val();
            if (buyer) {

                const password = buyer.password; 
    
                
                signInWithEmailAndPassword(auth, login_email, password)
                    .then(() => {
                        return deleteUser(auth.currentUser);
                    })
                    .then(() => {
                        console.log("User authentication deleted successfully.");
    
                        return remove(buyerRef); 
                    })
                    .then(() => {
                        console.log('Buyer record deleted from database successfully.');
    
                        if (profileImageUrl) {
                            const profileImageRef = storageRef(storage, profileImageUrl);
                            return deleteObject(profileImageRef);
                        }
                    })
                    .then(() => {
                        console.log('Profile image deleted successfully.');

                        if (valididImageUrl) {
                            const valididImageRef = storageRef(storage, valididImageUrl);
                            return deleteObject(valididImageRef);
                        }
                    })
                    .then(() => {
                        console.log('Permit image deleted successfully.');
                        alert("Buyer declined and record successfully deleted.");
                    })
                    .catch((error) => {
                        console.error('Error during the decline process:', error);
                        alert("Error declining buyer: " + error.message);
                    });
            } else {
                alert("Buyer data not found.");
            }
        });
    }


    // Function to zoom permit image
    window.zoomPermitImage = function(img) {
        // Implement zoom functionality here, e.g., opening the image in a modal
        const modal = document.createElement('div');
        modal.style.position = 'fixed';
        modal.style.top = '0';
        modal.style.left = '0';
        modal.style.width = '100%';
        modal.style.height = '100%';
        modal.style.backgroundColor = 'rgba(0,0,0,0.8)';
        modal.style.display = 'flex';
        modal.style.alignItems = 'center';
        modal.style.justifyContent = 'center';
        modal.onclick = () => document.body.removeChild(modal);

        const modalImg = document.createElement('img');
        modalImg.src = img.src;
        modalImg.style.maxWidth = '90%';
        modalImg.style.maxHeight = '90%';

        modal.appendChild(modalImg);
        document.body.appendChild(modal);
    }

    // Function to send approval email to buyer
    function sendApprovalEmail(login_email) {
        const templateParams = {
            email: login_email,
            name: "Buyer"
        };

        emailjs.send('service_u6rit42', 'template_3lo6l2f', templateParams)
            .then((response) => {
                console.log('Success:', response);
                alert('Approval email sent successfully.');
            }, (error) => {
                console.error('Error:', error);
                alert('Failed to send approval email.');
            });
    }

    // Function to send decline email to buyer
    function sendEmail(reason, login_email) {
        const templateParams = {
            decline_reason: reason,
            email: login_email,
            name: "Buyer"
        };

        emailjs.send('service_u6rit42', 'template_svvgufp', templateParams)
            .then((response) => {
                console.log('Success:', response);
                alert('Decline email sent successfully.');
            }, (error) => {
                console.error('Error:', error);
                alert('Failed to send decline email.');
            });
    }

    // Load buyer data from Firebase and populate the table
    onValue(buyersRef, (snapshot) => {
        const buyerTableBody = document.getElementById('buyer-table-body');
        buyerTableBody.innerHTML = '';
    
        const now = new Date().getTime(); // Current timestamp
        const threeDaysInMilliseconds = 3 * 24 * 60 * 60 * 1000; // 3 days in milliseconds
    
        snapshot.forEach((childSnapshot) => {
            const buyer = childSnapshot.val();
            
            // Check if the buyer is approved and validate the approvedAt timestamp
            if (buyer.status === 'approved' && buyer.approvedAt) {
                const approvedAtTimestamp = new Date(buyer.approvedAt).getTime();
                
                // If approved date is older than 3 days, delete valididImageUrl
                if (now - approvedAtTimestamp > threeDaysInMilliseconds) {
                    // Delete from storage
                    if (buyer.valididImageUrl) {
                        const valididImageRef = storageRef(storage, buyer.valididImageUrl);
                        deleteObject(valididImageRef)
                            .then(() => {
                                console.log(`Deleted valididImageUrl: ${buyer.valididImageUrl}`);
                            })
                            .catch((error) => {
                                console.error('Error deleting image from storage:', error);
                            });
                    }
    
                    // Remove valididImageUrl from the database
                    const buyerRef = ref(database, 'buyers/' + childSnapshot.key);
                    update(buyerRef, { valididImageUrl: null })
                        .then(() => {
                            console.log(`Removed valididImageUrl from buyer: ${buyer.userId}`);
                        })
                        .catch((error) => {
                            console.error('Error updating buyer record:', error);
                        });
                }
            }
    
            // Only display pending buyers in the table
            if (buyer.status === 'pending') {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>
                        <div class="profile-container">
                            <img class="pic1" src="${buyer.profileImageUrl}" alt="Profile Image">
                        </div>
                    </td>
                    <td><img class="pic" src="${buyer.valididImageUrl}" alt="Permit Image" onclick="zoomPermitImage(this)"></td>
                    <td>${buyer.firstName} ${buyer.lastName}</td>
                    <td>
                        <button class="btn-btn3" onclick="viewBuyerInfo('${buyer.userId}')">View</button>
                        <button class="btn-btn1" onclick="approveBuyer('${buyer.userId}', '${buyer.login_email}')">Accept</button>
                        <button class="btn-btn2" onclick="declineBuyer('${buyer.userId}', '${buyer.login_email}', '${buyer.profileImageUrl}', '${buyer.valididImageUrl}')">Decline</button>
                    </td>
                `;
                buyerTableBody.appendChild(row);
            }
        });
    });


    // Function to open the vendor info modal when "View" is clicked
    window.viewBuyerInfo = function(buyerId) {
        const buyerRef = ref(database, 'buyers/' + buyerId);
        onValue(buyerRef, (snapshot) => {
            const buyer = snapshot.val();
            if (buyer) {
                const buyerInfo = `
                    <strong>Owner:</strong> ${buyer.firstName} ${buyer.lastName}<br>
                    <strong>Email:</strong> ${buyer.login_email}<br>
                    <strong>Phone:</strong> ${buyer.phone}<br>
                    <strong>City:</strong> ${buyer.cities}, ${buyer.barangay}, ${buyer.provinces}<br>
                `;
                document.getElementById('buyerInfo').innerHTML = buyerInfo;
    
                // Display the modal
                document.getElementById('buyerInfoModal').style.display = 'flex';
            }
        });
    };
    
    // Function to close the vendor info modal
    document.getElementById('closeBuyerInfoBtn').onclick = function() {
        document.getElementById('buyerInfoModal').style.display = 'none';
    };
    
    // Ensure the modal closes if the user clicks outside the modal content
    window.onclick = function(event) {
        const modal = document.getElementById('buyerInfoModal');
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    };

    // Show notification modal when notification bell is clicked
    const notificationBell = document.getElementById('notificationBell');
    const notificationModal = document.getElementById('notificationModal');
    notificationBell.addEventListener('click', () => {
        notificationModal.style.display = 'block';
    });

    // Close notification modal when close button is clicked
    const closeNotificationModalBtn = document.getElementById('closeNotificationModalBtn');
    closeNotificationModalBtn.addEventListener('click', () => {
        notificationModal.style.display = 'none';
    });

    // Close notification modal when clicking outside the modal
    window.addEventListener('click', (event) => {
        if (event.target === notificationModal) {
            notificationModal.style.display = 'none';
        }
    });
</script>
