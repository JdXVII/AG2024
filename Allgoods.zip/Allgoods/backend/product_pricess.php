<script type="module">
    import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-app.js";
    import { getDatabase, ref, push, set, get, update, remove } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-database.js";
    import { getStorage, ref as storageRef, uploadBytes, getDownloadURL, deleteObject } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-storage.js";

    const firebaseConfig = {
      apiKey: "AIzaSyCSx9Dx9f6fbwBvf8b02Wo8W6py5mFkpzI",
      authDomain: "allgoods2024-5163a.firebaseapp.com",
      databaseURL: "https://allgoods2024-5163a-default-rtdb.firebaseio.com",
      projectId: "allgoods2024-5163a",
      storageBucket: "allgoods2024-5163a.appspot.com",
      messagingSenderId: "980525971714",
      appId: "1:980525971714:web:78849efcc5ac2325a7ea1b"
    };

    const app = initializeApp(firebaseConfig);
    const database = getDatabase(app);
    const storage = getStorage(app);

    let currentProductId = null;

    // Function to add a product
async function addProduct(name, price, quantity, imageFile, category) {
    try {
        const newProductRef = push(ref(database, 'products/'));

        // Upload image
        const imageRef = storageRef(storage, 'product_images/' + newProductRef.key + '_' + imageFile.name);
        await uploadBytes(imageRef, imageFile);
        const imageUrl = await getDownloadURL(imageRef);

        // Set current date for history entry
        const currentDate = new Date().toLocaleDateString();
        const initialHistoryEntry = { date: currentDate, price: price };

        // Save product details with timestamp and initial history
        await set(newProductRef, {
            name: name,
            price: price,
            quantity: quantity,
            image: imageUrl,
            category: category,
            history: [initialHistoryEntry], // Add the initial price entry to history
            createdAt: new Date().toISOString() 
        });

        showPopupMessage('Product added successfully!');
        loadProducts();
    } catch (error) {
        console.error("Error adding product: ", error);
        showPopupMessage('Error adding product: ' + error.message, true);
    }
}


    document.getElementById('productForm').addEventListener('submit', function(e) {
        e.preventDefault();
        const name = document.getElementById('productName').value;
        const price = document.getElementById('productPrice').value;
        const quantity = document.getElementById('productQuantity').value;
        const imageFile = document.getElementById('productImage').files[0];
        const category = document.getElementById('productCategory').value;

        const priceParts = price.split('-').map(part => part.trim());
        const minPrice = priceParts[0];
        const maxPrice = priceParts[1] || minPrice;

        // Add product with min and max price
        addProduct(name, { min: minPrice, max: maxPrice }, quantity, imageFile, category);

        document.getElementById('productForm').reset();
    });

    // Attach a one-time event listener for the update form submission
document.getElementById('updateForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const price = document.getElementById('updateProductPrice').value;

    // Validation for correct price format and range
    const pricePattern = /^\d+\s*-\s*\d+$/;
    if (!pricePattern.test(price)) {
        showPopupMessage('Invalid format! Please enter a price range in the format "min - max" with only numbers.', true);
        return;
    }

    const priceParts = price.split('-').map(part => parseFloat(part.trim()));
    const minPrice = priceParts[0];
    const maxPrice = priceParts[1];

    // Validation to ensure min is not greater than max
    if (minPrice > maxPrice) {
        showPopupMessage('Invalid price range! The minimum price cannot be greater than the maximum price.', true);
        return;
    }

    updateProductPrice(currentProductId, { min: minPrice, max: maxPrice });
    document.getElementById('updatePopup').style.display = 'none';
});

    // Open update popup and set the current product ID
    function openUpdatePopup(productId, product) {
        currentProductId = productId;
        document.getElementById('updateProductName').value = product.name;
        document.getElementById('updateProductPrice').value = product.price.min + ' - ' + product.price.max;
        document.getElementById('updatePopup').style.display = 'flex';
    }

    // Update product price in Firebase and add to history
    async function updateProductPrice(productId, price) {
        try {
            const currentDate = new Date().toLocaleDateString();
            const historyEntry = { date: currentDate, price: price };

            await update(ref(database, 'products/' + productId), {
                price: price,
                history: [...(await getHistory(productId)), historyEntry]
            });
            showPopupMessage('Product price updated successfully!');
            await loadProducts();
        } catch (error) {
            console.error("Error updating product price: ", error);
            showPopupMessage('Error updating product price: ' + error.message, true);
        }
    }

    // Fetch the current history for a product
    async function getHistory(productId) {
        const productSnapshot = await get(ref(database, 'products/' + productId));
        return productSnapshot.val().history || [];
    }

    // Close update popup
    document.querySelector('.close-btn').addEventListener('click', function() {
        document.getElementById('updatePopup').style.display = 'none';
    });

    // Load products from Firebase
    async function loadProducts() {
        try {
            const productTable = document.getElementById('productTable');
            productTable.innerHTML = '';
    
            const productsSnapshot = await get(ref(database, 'products/'));
            const products = productsSnapshot.val();
    
            if (products) {
                // Convert products object to an array and sort by createdAt
                const productArray = Object.entries(products).map(([key, value]) => ({ id: key, ...value }));
                productArray.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)); // Sort by createdAt in descending order
    
                productArray.forEach(product => {
                    const row = document.createElement('tr');
    
                    const imageCell = document.createElement('td');
                    const imageElement = document.createElement('img');
                    imageElement.src = product.image;
                    imageElement.classList.add('pic');
                    imageCell.appendChild(imageElement);
                    row.appendChild(imageCell);
    
                    const nameCell = document.createElement('td');
                    nameCell.textContent = product.name;
                    row.appendChild(nameCell);
    
                    const priceCell = document.createElement('td');
                    priceCell.textContent = product.price.min + ' - ' + product.price.max;
                    row.appendChild(priceCell);
    
                    const quantityCell = document.createElement('td');
                    quantityCell.textContent = product.quantity;
                    row.appendChild(quantityCell);
    
                    const categoryCell = document.createElement('td');
                    categoryCell.textContent = product.category;
                    row.appendChild(categoryCell);
    
                    const actionCell = document.createElement('td');
    
                    const updateButton = document.createElement('button');
                    updateButton.classList.add('update-btn');
                    updateButton.textContent = 'Update';
                    updateButton.addEventListener('click', function() {
                        openUpdatePopup(product.id, product);
                    });
                    actionCell.appendChild(updateButton);
    
                    const viewButton = document.createElement('button');
                    viewButton.classList.add('view-btn');
                    viewButton.textContent = 'View History';
                    viewButton.addEventListener('click', function() {
                        viewPriceHistory(product.history);
                    });
                    actionCell.appendChild(viewButton);
    
                    const deleteButton = document.createElement('button');
                    deleteButton.classList.add('delete-btn');
                    deleteButton.textContent = 'Delete';
                    deleteButton.addEventListener('click', function() {
                        deleteProduct(product.id);
                    });
                    actionCell.appendChild(deleteButton);
    
                    row.appendChild(actionCell);
                    productTable.appendChild(row);
                });
            }
        } catch (error) {
            console.error("Error loading products: ", error);
        }
    }


    // Function to delete a product from Firebase with confirmation
    async function deleteProduct(productId) {
        try {
            const confirmDelete = confirm("Are you sure you want to delete this product?");
            if (confirmDelete) {
                const productSnapshot = await get(ref(database, 'products/' + productId));
                const product = productSnapshot.val();
                const imageUrl = product.image;
                const imageRef = storageRef(storage, imageUrl);

                await deleteObject(imageRef);
                await remove(ref(database, 'products/' + productId));
                showPopupMessage('Product deleted successfully!');
                loadProducts();
            }
        } catch (error) {
            console.error("Error deleting product: ", error);
            showPopupMessage('Error deleting product: ' + error.message, true);
        }
    }

    // Dropdown and search filter
    document.getElementById('categoryDropdown').addEventListener('change', filterProducts);
    document.getElementById('searchInput').addEventListener('input', filterProducts);

    function filterProducts() {
        const searchText = document.getElementById('searchInput').value.toLowerCase().trim();
        const selectedCategory = document.getElementById('categoryDropdown').value.toLowerCase();
        const productRows = document.querySelectorAll('#productTable tr');

        productRows.forEach(row => {
            const productName = row.querySelector('td:nth-child(2)').textContent.toLowerCase();
            const productCategory = row.querySelector('td:nth-child(5)').textContent.toLowerCase();

            const matchesCategory = selectedCategory === '' || productCategory.includes(selectedCategory);
            const matchesSearch = productName.includes(searchText);

            row.style.display = matchesCategory && matchesSearch ? '' : 'none';
        });
    }

    // Function to show popup message
    function showPopupMessage(message, isError = false) {
        const popupMessage = document.getElementById('popupMessage');
        popupMessage.textContent = message;
        popupMessage.classList.toggle('error', isError);
        popupMessage.style.display = 'block';

        setTimeout(() => {
            popupMessage.style.display = 'none';
        }, 3000);
    }

    // View price history
    function viewPriceHistory(history) {
        const historyContainer = document.getElementById('historyContainer');
        historyContainer.innerHTML = ''; // Clear previous entries
    
        // Sort history in reverse order (latest first)
        const sortedHistory = history.sort((a, b) => new Date(b.date) - new Date(a.date));
    
        sortedHistory.forEach(entry => {
            const historyEntry = document.createElement('p');
            historyEntry.classList.add('history-entry_history'); // Updated class name
            historyEntry.textContent = `${entry.date}: Price (min - max) ${entry.price.min} - ${entry.price.max}`;
            historyContainer.appendChild(historyEntry);
        });
    
        // Display the popup
        const historyPopup = document.getElementById('historyPopup');
        historyPopup.style.display = 'block';
    }
    
    // Close history popup
    function closeHistoryPopup() {
        const historyPopup = document.getElementById('historyPopup');
        historyPopup.style.display = 'none';
    }


    // Initial load of products
    loadProducts();
</script>
