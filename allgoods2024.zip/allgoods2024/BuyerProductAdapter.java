package com.example.allgoods2024;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

public class BuyerProductAdapter extends RecyclerView.Adapter<BuyerProductAdapter.ProductViewHolder> {

    private List<Product> productList;
    private OnItemClickListener listener;

    private String formatSoldNumber(String sold) {
        try {
            int soldInt = Integer.parseInt(sold);
            if (soldInt >= 1000) {
                double formattedValue = soldInt / 1000.0;
                return String.format("%.1fk", formattedValue);
            } else {
                return sold;
            }
        } catch (NumberFormatException e) {
            // Handle the case where parsing fails
            return sold;
        }
    }

    public interface OnItemClickListener {
        void onItemClick(Product product);
    }

    public BuyerProductAdapter(List<Product> productList, OnItemClickListener listener) {
        this.productList = productList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.buyer_item_product, parent, false);
        return new ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductViewHolder holder, int position) {
        Product product = productList.get(position);
        holder.bind(product, listener);
    }

    @Override
    public int getItemCount() {
        return productList.size();
    }

    public class ProductViewHolder extends RecyclerView.ViewHolder {
        ImageView productImage;
        TextView productName, productPrice, productSale, productStock, productCategory, productDesc;

        public ProductViewHolder(@NonNull View itemView) {
            super(itemView);
            productImage = itemView.findViewById(R.id.product_image);
            productName = itemView.findViewById(R.id.product_name);
            productPrice = itemView.findViewById(R.id.product_price);
            productSale = itemView.findViewById(R.id.product_sale);
            productStock = itemView.findViewById(R.id.product_stock);
            productCategory = itemView.findViewById(R.id.product_category);
            productDesc = itemView.findViewById(R.id.product_desc);
        }

        public void bind(final Product product, final OnItemClickListener listener) {
            // Get the first image URL from the List<String>
            if (product.getImageUrls() != null && !product.getImageUrls().isEmpty()) {
                String firstImageUrl = product.getImageUrls().get(0);
                Glide.with(itemView.getContext()).load(firstImageUrl).into(productImage);
            }

            productName.setText(product.getName());
            productPrice.setText("₱" + product.getPrice());
            productSale.setText("-" + product.getSale());
            productStock.setText(String.format("%.2f", product.getAverageRating()) + " (" + product.getUserRatingCount() + ") " + formatSoldNumber(product.getSold()) + " sold");
            productCategory.setText(product.getCategory() + " (" + product.getType() + ")");
            productDesc.setText(product.getDescription());

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onItemClick(product);
                }
            });
        }

    }
}
