package com.example.allgoods2024;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ProductViewHolder> {

    private Context context;
    private List<Product> productList;
    private OnItemClickListener onItemClickListener;
    private String formatSoldNumber(String sold) {
        try {
            int soldInt = Integer.parseInt(sold);
            if (soldInt >= 1000) {
                double formattedValue = soldInt / 1000.0;
                return String.format("%.1fk", formattedValue);
            } else {
                return sold;
            }
        } catch (NumberFormatException e) {
            // Handle the case where parsing fails
            return sold;
        }
    }

    public interface OnItemClickListener {
        void onItemClick(String productId);
    }

    public ProductAdapter(Context context, List<Product> productList, OnItemClickListener onItemClickListener) {
        this.context = context;
        this.productList = productList;
        this.onItemClickListener = onItemClickListener;
    }

    @NonNull
    @Override
    public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_product, parent, false);
        return new ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductViewHolder holder, int position) {
        Product product = productList.get(position);
        holder.productName.setText(product.getName());
        holder.productPrice.setText("₱" + product.getPrice());
        holder.productStock.setText("Stock: " + product.getStock());
        holder.productCategory.setText(product.getCategory());
        holder.productStatus.setText(String.format("%.2f", product.getAverageRating()) + " (" + product.getUserRatingCount() + ") " + formatSoldNumber(product.getSold()));
        Glide.with(context).load(product.getImageUrls().get(0)).into(holder.productImage);

        holder.productImage.setOnClickListener(v -> {
            if (onItemClickListener != null) {
                onItemClickListener.onItemClick(product.getProductId());
            }
        });
    }

    @Override
    public int getItemCount() {
        return productList.size();
    }

    public static class ProductViewHolder extends RecyclerView.ViewHolder {

        ImageView productImage;
        TextView productName;
        TextView productPrice;
        TextView productStock;
        TextView productCategory;
        TextView productStatus;

        public ProductViewHolder(@NonNull View itemView) {
            super(itemView);
            productImage = itemView.findViewById(R.id.product_image);
            productName = itemView.findViewById(R.id.product_name);
            productPrice = itemView.findViewById(R.id.product_price);
            productStock = itemView.findViewById(R.id.product_stock);
            productCategory = itemView.findViewById(R.id.product_category);
            productStatus = itemView.findViewById(R.id.product_status);
        }
    }
}
