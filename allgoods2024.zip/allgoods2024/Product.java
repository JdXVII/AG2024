package com.example.allgoods2024;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

public class Product implements Parcelable {
    private String productId;
    private String name;
    private String stock;
    private String description;
    private String price;
    private String category;
    private List<String> imageUrls; // Modified to List<String>
    private String status;
    private String userId;
    private String type;
    private String sale;
    private String storeName;
    private String deliveryOption;
    private String sold;
    private String paymentOption;

    // Rating fields
    private int userRatingCount;  // Number of users who have rated the product
    private int totalRatings;      // Total sum of all ratings
    private float averageRating;   // Average rating of the product

    // GCash fields
    private String gcashNumber;
    private String gcashName;

    public Product() {
    }

    public Product(String productId, String name, String stock, String description, String price, String category, List<String> imageUrls, String status, String userId, String type, String sale, String storeName, String deliveryOption, String sold, String paymentOption, int userRatingCount, int totalRatings, float averageRating, String gcashNumber, String gcashName) {
        this.productId = productId;
        this.name = name;
        this.stock = stock;
        this.description = description;
        this.price = price;
        this.category = category;
        this.imageUrls = imageUrls; // Modified to List<String>
        this.status = status;
        this.userId = userId;
        this.type = type;
        this.sale = sale;
        this.storeName = storeName;
        this.deliveryOption = deliveryOption;
        this.sold = sold;
        this.paymentOption = paymentOption;
        this.userRatingCount = userRatingCount;
        this.totalRatings = totalRatings;
        this.averageRating = averageRating;
        this.gcashNumber = gcashNumber;
        this.gcashName = gcashName;
    }

    protected Product(Parcel in) {
        productId = in.readString();
        name = in.readString();
        stock = in.readString();
        description = in.readString();
        price = in.readString();
        category = in.readString();
        imageUrls = in.createStringArrayList(); // Modified to read List<String>
        status = in.readString();
        userId = in.readString();
        type = in.readString();
        sale = in.readString();
        storeName = in.readString();
        deliveryOption = in.readString();
        sold = in.readString();
        paymentOption = in.readString();
        userRatingCount = in.readInt();
        totalRatings = in.readInt();
        averageRating = in.readFloat();
        gcashNumber = in.readString();
        gcashName = in.readString();
    }

    public static final Creator<Product> CREATOR = new Creator<Product>() {
        @Override
        public Product createFromParcel(Parcel in) {
            return new Product(in);
        }

        @Override
        public Product[] newArray(int size) {
            return new Product[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(productId);
        dest.writeString(name);
        dest.writeString(stock);
        dest.writeString(description);
        dest.writeString(price);
        dest.writeString(category);
        dest.writeStringList(imageUrls); // Modified to write List<String>
        dest.writeString(status);
        dest.writeString(userId);
        dest.writeString(type);
        dest.writeString(sale);
        dest.writeString(storeName);
        dest.writeString(deliveryOption);
        dest.writeString(sold);
        dest.writeString(paymentOption);
        dest.writeInt(userRatingCount);
        dest.writeInt(totalRatings);
        dest.writeFloat(averageRating);
        dest.writeString(gcashNumber);
        dest.writeString(gcashName);
    }

    // Getters and Setters
    public String getProductId() { return productId; }
    public String getName() { return name; }
    public String getStock() { return stock; }
    public String getDescription() { return description; }
    public String getPrice() { return price; }
    public String getCategory() { return category; }
    public List<String> getImageUrls() { return imageUrls; } // Getter for List<String>
    public String getStatus() { return status; }
    public String getUserId() { return userId; }
    public String getType() { return type; }
    public String getSale() { return sale; }
    public String getStoreName() { return storeName; }
    public String getDeliveryOption() { return deliveryOption; }
    public String getSold() { return sold; }
    public String getPaymentOption() { return paymentOption; }

    public int getUserRatingCount() { return userRatingCount; }
    public int getTotalRatings() { return totalRatings; }
    public float getAverageRating() { return averageRating; }

    public String getGcashNumber() { return gcashNumber; }  // Getter for gcashNumber
    public String getGcashName() { return gcashName; }      // Getter for gcashName

    public void setImageUrls(List<String> imageUrls) { this.imageUrls = imageUrls; } // Setter for List<String>
    public void setStock(String stock) { this.stock = stock; }
    public void setSold(String sold) { this.sold = sold; }
    public void setPaymentOption(String paymentOption) { this.paymentOption = paymentOption; }

    public void setUserRatingCount(int userRatingCount) { this.userRatingCount = userRatingCount; }
    public void setTotalRatings(int totalRatings) { this.totalRatings = totalRatings; }
    public void setAverageRating(float averageRating) { this.averageRating = averageRating; }

    public void setGcashNumber(String gcashNumber) { this.gcashNumber = gcashNumber; }
    public void setGcashName(String gcashName) { this.gcashName = gcashName; }

    public String getProductName() { return name; }

    public void setProductName(String name) {
        this.name = name;
    }
}
