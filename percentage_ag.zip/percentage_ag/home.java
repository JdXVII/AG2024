package com.example.percentage_ag;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.os.Bundle;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;
import android.widget.RadioGroup;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class home extends AppCompatActivity {

    private BroadcastReceiver networkReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (isInternetAvailable(context)) {
                // If internet is available, reload the data
                fetchVendorData();
            } else {
                // Optionally, show a message indicating no connection
                Toast.makeText(home.this, "No internet connection.", Toast.LENGTH_SHORT).show();
            }
        }
    };

    private RecyclerView vendorRecyclerView;
    private VendorAdapter vendorAdapter;
    private List<Vendor> vendorList;
    private SearchView searchView;

    private RadioGroup radioGroupFilter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // Set status bar color to black for Android 7.0 (Nougat) and above
        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.setStatusBarColor(ContextCompat.getColor(this, android.R.color.black));

        searchView = findViewById(R.id.searchView);

        // Initialize RecyclerView
        vendorRecyclerView = findViewById(R.id.vendorRecyclerView);
        vendorRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        vendorList = new ArrayList<>();
        vendorAdapter = new VendorAdapter(vendorList);
        vendorRecyclerView.setAdapter(vendorAdapter);

        // Initialize RadioGroup and RadioButtons
        radioGroupFilter = findViewById(R.id.radioGroupFilter);

        radioGroupFilter.setOnCheckedChangeListener((group, checkedId) -> {
            String filter = "";

            if (checkedId == R.id.radioNew) {
                filter = "New";
            } else if (checkedId == R.id.radioPending) {
                filter = "Pending";
            } else if (checkedId == R.id.radioClaim) {
                filter = "Claim";
            } else if (checkedId == R.id.radioAll) {
                filter = "All";  // Show all vendors
            }

            filterVendors(filter);
        });

        // Register network connectivity receiver
        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(networkReceiver, filter);

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                filterStore(query); // Filter based on search query and selected category
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filterStore(newText); // Filter as the user types
                return true;
            }
        });

        searchView.setQueryHint("Search...");
        int searchTextId = getResources().getIdentifier("android:id/search_src_text", null, null);
        TextView searchTextView = findViewById(searchTextId);
        if (searchTextView != null) {
            searchTextView.setTextColor(Color.GRAY); // Set the text color
        }

        fetchVendorData();
    }

    // Method to check internet availability
    private boolean isInternetAvailable(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm != null) {
            NetworkCapabilities nc = cm.getNetworkCapabilities(cm.getActiveNetwork());
            return nc != null && (nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR));
        }
        return false;
    }

    private void fetchVendorData() {
        DatabaseReference vendorRef = FirebaseDatabase.getInstance().getReference("vendors");

        vendorRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                vendorList.clear(); // Clear the list before adding new data
                for (DataSnapshot vendorSnapshot : snapshot.getChildren()) {
                    Vendor vendor = vendorSnapshot.getValue(Vendor.class);
                    vendorList.add(vendor);
                }
                vendorAdapter.notifyDataSetChanged(); // Notify the adapter that the data has changed
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("FirebaseError", error.getMessage());
            }
        });
    }

    private void filterVendors(String filter) {
        List<Vendor> filteredList = new ArrayList<>();

        if (filter.equals("All")) {
            filteredList.addAll(vendorList); // Add all vendors
        } else {
            for (Vendor vendor : vendorList) {
                String claimPendingNew = vendor.getClaimPendingNew(); // Assuming this getter exists

                // Ensure that claimPendingNew is not null before comparing
                if (claimPendingNew != null && claimPendingNew.equalsIgnoreCase(filter)) {
                    filteredList.add(vendor);
                }
            }
        }

        // Update the adapter with the filtered list
        vendorAdapter.updateList(filteredList);
    }

    private void filterStore(String query) {
        String selectedCategory = getSelectedCategoryFromRadioGroup(); // Get the selected category
        filterStore(query, selectedCategory); // Call the overloaded method
    }

    private void filterStore(String query, String category) {
        List<Vendor> filteredList = new ArrayList<>();
        filteredList.clear();

        if (category.equals("All")) {
            for (Vendor vendor : vendorList) {
                if (vendor.getStoreName() != null && vendor.getStoreName().toLowerCase().contains(query.toLowerCase())) {
                    filteredList.add(vendor);
                }
            }
        } else {
            for (Vendor vendor : vendorList) {
                if (vendor.getClaimPendingNew() != null && vendor.getClaimPendingNew().equalsIgnoreCase(category) &&
                        vendor.getStoreName() != null && vendor.getStoreName().toLowerCase().contains(query.toLowerCase())) {
                    filteredList.add(vendor);
                }
            }
        }

        vendorAdapter.updateList(filteredList);
    }

    private String getSelectedCategoryFromRadioGroup() {
        int checkedId = radioGroupFilter.getCheckedRadioButtonId();
        if (checkedId == R.id.radioNew) {
            return "New";
        } else if (checkedId == R.id.radioPending) {
            return "Pending";
        } else if (checkedId == R.id.radioClaim) {
            return "Claim";
        } else if (checkedId == R.id.radioAll) {
            return "All";
        }
        return "All";
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(home.this, MainActivity2.class);
        startActivity(intent);
        finish();
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Unregister the network receiver
        unregisterReceiver(networkReceiver);
    }
}
