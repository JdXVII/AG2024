package com.example.percentage_ag;

public class Vendor {
    private String firstName;
    private String lastName;
    private String storeName;
    private String status;
    private String profileImageUrl;
    private String userId;
    private String claimPendingNew;

    // Required empty constructor for Firebase
    public Vendor() {
    }

    public Vendor(String firstName, String lastName, String storeName, String status, String profileImageUrl, String userId) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.storeName = storeName;
        this.status = status;
        this.profileImageUrl = profileImageUrl;
        this.userId = userId; // Initialize userId
    }

    // Getters
    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getStoreName() {
        return storeName;
    }

    public String getStatus() {
        return status;
    }

    public String getProfileImageUrl() {
        return profileImageUrl; // Getter for profile image URL
    }

    public String getUserId() { // Getter for userId
        return userId;
    }

    // Optionally, you can add setters if you need to update the fields
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setProfileImageUrl(String profileImageUrl) {
        this.profileImageUrl = profileImageUrl;
    }

    public void setUserId(String userId) { // Setter for userId
        this.userId = userId;
    }

    public String getClaimPendingNew() {
        return claimPendingNew;
    }

    public void setClaimPendingNew(String claimPendingNew) {
        this.claimPendingNew = claimPendingNew;
    }
}
