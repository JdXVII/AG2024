package com.example.percentage_ag;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class view_receipt extends AppCompatActivity {

    private BroadcastReceiver networkReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (isInternetAvailable(context)) {
                // If internet is available, reload the data

            } else {
                Toast.makeText(view_receipt.this, "No internet connection.", Toast.LENGTH_SHORT).show();
            }
        }
    };

    private RecyclerView receiptRecyclerView;
    private ReceiptAdapter receiptAdapter;
    private List<Receipt> receiptList;
    private TextView noReceiptTextView;

    private DatabaseReference receiptRef;
    private ImageView back_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_receipt);

        // Register network connectivity receiver
        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(networkReceiver, filter);

        // Set status bar color to black for Android 7.0 (Nougat) and above
        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.setStatusBarColor(getResources().getColor(android.R.color.black));

        // Initialize views
        receiptRecyclerView = findViewById(R.id.receiptRecyclerView);
        noReceiptTextView = findViewById(R.id.noReceiptTextView);
        receiptList = new ArrayList<>();
        receiptAdapter = new ReceiptAdapter(receiptList);
        back_button = findViewById(R.id.back_button);

        // Set up RecyclerView
        receiptRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        receiptRecyclerView.setAdapter(receiptAdapter);

        back_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent back = new Intent(view_receipt.this, view_vendor.class);
                startActivity(back);
                finish();
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            }
        });

        // Initialize Firebase reference
        receiptRef = FirebaseDatabase.getInstance().getReference("receipt");

        // Retrieve userId from the intent
        String userId = getIntent().getStringExtra("userId");
        if (userId != null) {
            fetchReceipts(userId);
        }
    }

    // Method to check internet availability
    private boolean isInternetAvailable(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm != null) {
            NetworkCapabilities nc = cm.getNetworkCapabilities(cm.getActiveNetwork());
            return nc != null && (nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR));
        }
        return false;
    }

    private void fetchReceipts(String userId) {
        receiptRef.orderByChild("userId").equalTo(userId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                receiptList.clear(); // Clear existing receipts
                for (DataSnapshot receiptSnapshot : snapshot.getChildren()) {
                    Receipt receipt = receiptSnapshot.getValue(Receipt.class);
                    if (receipt != null) {
                        receiptList.add(receipt);
                    }
                }

                // Check if receipts are found and update UI accordingly
                if (receiptList.isEmpty()) {
                    noReceiptTextView.setVisibility(View.VISIBLE);
                    receiptRecyclerView.setVisibility(View.GONE);
                } else {
                    noReceiptTextView.setVisibility(View.GONE);
                    receiptRecyclerView.setVisibility(View.VISIBLE);
                    receiptAdapter.notifyDataSetChanged(); // Notify adapter of changes
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Handle error
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(view_receipt.this, view_vendor.class);
        startActivity(intent);
        finish();
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Unregister the network receiver
        unregisterReceiver(networkReceiver);
    }
}
